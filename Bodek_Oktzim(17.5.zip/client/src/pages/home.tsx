import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, CheckCircle2 } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center gap-3">
          <Bot className="h-8 w-8 text-primary" data-testid="icon-bot" />
          <CardTitle data-testid="text-title">Telegram Bot</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <span data-testid="text-status">Service is running</span>
          </div>
          <p className="text-sm text-muted-foreground" data-testid="text-description">
            This service hosts a Telegram bot. There is no web interface — head
            to Telegram to interact with the bot.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
