import type { Express } from "express";
import type { Server } from "http";
import https from "https";
import http from "http";
import { log } from "./logger";

// ─── Google Sheets phone database ───────────────────────────────────────────

const SHEET_URL =
  "https://docs.google.com/spreadsheets/d/18RfRhdFg1m_lNZecRXl9rLwaxRto_VtlkDjjI5B2gL4/gviz/tq?tqx=out:csv";

const REPORT_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSd-IDkaGSpzk8f5Vw1e8QhiFo_kBs7ID_ojhpdYoVLyT-rvpw/viewform";

let phoneList: string[] = [];


function fetchText(url: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https") ? https : http;
    client
      .get(url, (res) => {
        let data = "";
        res.on("data", (chunk: Buffer) => (data += chunk));
        res.on("end", () => resolve(data));
      })
      .on("error", reject);
  });
}

async function loadPhoneList(): Promise<void> {
  try {
    const csv = await fetchText(SHEET_URL);
    const parsed = csv
      .split(/\r?\n/)
      .map((line: string) => line.replace(/[",]/g, "").trim())
      .filter((num: string) => num.length >= 3);
    phoneList = [...new Set(parsed)].sort((a: string, b: string) =>
      a.replace(/\D/g, "").localeCompare(b.replace(/\D/g, ""), undefined, { numeric: true })
    );
    log("Phone list loaded from Sheets: " + phoneList.length + " entries", "bot");
  } catch (err) {
    log("Error loading phone list: " + err, "bot");
  }
}

// ─── Phone normalisation ─────────────────────────────────────────────────────

function normalizePhone(input: string): string {
  let clean = input.replace(/\D/g, "");
  if (clean.startsWith("972")) {
    clean = "0" + clean.slice(3);
  } else if (clean.length === 9 && !clean.startsWith("0")) {
    clean = "0" + clean;
  }
  return clean;
}

// ─── Message handler (HTML parse mode — no Markdown underscore issues) ────────
// Unicode escapes used throughout so Hebrew text survives any encoding round-trip.
// \u05D1\u05E8\u05D5\u05DB\u05D9\u05DD = ברוכים  \u05D4\u05D1\u05D0\u05D9\u05DD = הבאים etc.

function buildWelcome(): string {
  return (
    "<b>\u05D1\u05E8\u05D5\u05DB\u05D9\u05DD \u05D4\u05D1\u05D0\u05D9\u05DD \u05DC\u05D1\u05D5\u05D3\u05E7 \u05E2\u05D5\u05E7\u05E6\u05D9\u05DD \u05D1\u05D9\u05EA\"\u05E8</b> \u2705\n\n" +
    "\u2022 \u05E9\u05DC\u05D7\u05D5 \u05DE\u05E1\u05E4\u05E8 \u05D8\u05DC\u05E4\u05D5\u05DF \u05D0\u05D5 \u05D7\u05DC\u05E7 \u05DE\u05DE\u05E0\u05D5 (\u05DE\u05D9\u05E0\u05D9\u05DE\u05D5\u05DD 3 \u05E1\u05E4\u05E8\u05D5\u05EA) \u05DC\u05D1\u05D3\u05D9\u05E7\u05D4 \uD83D\uDD0D\n" +
    "\u2022 \u05DB\u05EA\u05D1\u05D5 <b>\u05E8\u05E9\u05D9\u05DE\u05D4</b> \u05DB\u05D3\u05D9 \u05DC\u05E7\u05D1\u05DC \u05D0\u05EA \u05DB\u05DC \u05D4\u05DE\u05E1\u05E4\u05E8\u05D9\u05DD \u05D1\u05DE\u05D0\u05D2\u05E8 \uD83D\uDCCB\n" +
    "\u2022 \u05DB\u05D3\u05D9 \u05DC\u05D3\u05D5\u05D5\u05D7 \u05E2\u05DC \u05E2\u05D5\u05E7\u05E5 \u05DB\u05EA\u05D1\u05D5 <b>\u05D3\u05D5\u05D5\u05D7</b> \uD83D\uDCE2\n\n" +
    "\u26A0\uFE0F \u05D2\u05DD \u05D0\u05DD \u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0 \u05D1\u05DE\u05D0\u05D2\u05E8 \u2014 \u05D6\u05D4 \u05DC\u05D0 \u05D0\u05D5\u05DE\u05E8 \u05E9\u05D4\u05D5\u05D0 \u05D0\u05DE\u05D9\u05DF. \u05EA\u05DE\u05D9\u05D3 \u05D4\u05D9\u05D5 \u05D6\u05D4\u05D9\u05E8\u05D9\u05DD!"
  );
}

function handleMessage(text: string): string {
  const trimmed = text.trim();

  // /start — case-insensitive, also handles /start@botname in groups
  const lower = trimmed.toLowerCase().split("@")[0];
  if (lower === "/start" || lower === "start") {
    return buildWelcome();
  }

  // "דווח" => report link
  if (trimmed === "\u05D3\u05D5\u05D5\u05D7" || trimmed === "/\u05D3\u05D5\u05D5\u05D7") {
    return (
      "\uD83D\uDCE2 <b>\u05DB\u05D3\u05D9 \u05DC\u05D3\u05D5\u05D5\u05D7 \u05E2\u05DC \u05E2\u05D5\u05E7\u05E5 \u05DC\u05D7\u05E5 \u05E2\u05DC \u05D4\u05E7\u05D9\u05E9\u05D5\u05E8 \u2B07\uFE0F</b>\n\n" +
      REPORT_URL
    );
  }

  // "רשימה" => list all numbers, numbered and sorted ascending
  // Each number wrapped in <code> so tapping it copies just the number (no index)
  // Returns a special marker so the route handler sends multiple messages if needed
  if (trimmed === "\u05E8\u05E9\u05D9\u05DE\u05D4" || trimmed === "/\u05E8\u05E9\u05D9\u05DE\u05D4") {
    if (phoneList.length === 0) {
      return "\u23F3 \u05D4\u05DE\u05D0\u05D2\u05E8 \u05E2\u05D3\u05D9\u05D9\u05DF \u05D1\u05D8\u05E2\u05D9\u05E0\u05D4, \u05D0\u05E0\u05D0 \u05E0\u05E1\u05D5 \u05E9\u05D5\u05D1 \u05D1\u05E2\u05D5\u05D3 \u05E8\u05D2\u05E2.";
    }
    return "__LIST__";
  }

  const clean = normalizePhone(trimmed);

  // Non-numeric, unrecognised input => show welcome
  if (clean.length < 3) {
    if (trimmed.length > 0 && !/^\d+$/.test(trimmed)) {
      return buildWelcome();
    }
    return "\u26A0\uFE0F \u05D4\u05D7\u05D9\u05E4\u05D5\u05E9 \u05E7\u05E6\u05E8 \u05DE\u05D3\u05D9. \u05E9\u05DC\u05D7\u05D5 \u05DC\u05E4\u05D7\u05D5\u05EA 3 \u05E1\u05E4\u05E8\u05D5\u05EA.";
  }

  if (phoneList.length === 0) {
    return "\u23F3 \u05D4\u05DE\u05D0\u05D2\u05E8 \u05E2\u05D3\u05D9\u05D9\u05DF \u05D1\u05D8\u05E2\u05D9\u05E0\u05D4, \u05D0\u05E0\u05D0 \u05E0\u05E1\u05D5 \u05E9\u05D5\u05D1 \u05D1\u05E2\u05D5\u05D3 \u05E8\u05D2\u05E2.";
  }

  // Exact match
  const exactMatch = phoneList.find((p: string) => p.replace(/\D/g, "") === clean);
  if (exactMatch) {
    return "\u05D4\u05DE\u05E1\u05E4\u05E8 " + trimmed + " \u05E2\u05D5\u05E7\u05E5 \u26A0\uFE0F";
  }

  // Partial match
  const partialMatches = phoneList.filter((p: string) =>
    p.replace(/\D/g, "").includes(clean)
  );
  if (partialMatches.length > 0) {
    const list = partialMatches.slice(0, 20).join("\n");
    const extra = partialMatches.length > 20
      ? "\n<i>...\u05D5\u05E2\u05D5\u05D3 " + (partialMatches.length - 20) + " \u05EA\u05D5\u05E6\u05D0\u05D5\u05EA</i>"
      : "";
    return (
      "\uD83D\uDD0D <b>\u05E0\u05DE\u05E6\u05D0\u05D5 " + partialMatches.length + " \u05D4\u05EA\u05D0\u05DE\u05D5\u05EA \u05E2\u05D1\u05D5\u05E8 &quot;" + trimmed + "&quot;:</b>\n\n" +
      list + extra
    );
  }

  // Not found
  return (
    "\u05D4\u05DE\u05E1\u05E4\u05E8 " + trimmed + " \u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0 \u05D1\u05DE\u05D0\u05D2\u05E8 \u274C\uFE0F\n\n" +
    "\u05D7\u05E9\u05D5\u05D1 \u05DC\u05D6\u05DB\u05D5\u05E8: \u05DC\u05D0 \u05D1\u05D8\u05D5\u05D7 \u05E9\u05D4\u05D5\u05D0 \u05D0\u05DE\u05D9\u05DF! \u05EA\u05DE\u05D9\u05D3 \u05EA\u05D4\u05D9\u05D5 \u05D6\u05D4\u05D9\u05E8\u05D9\u05DD."
  );
}

// ─── Telegram API helpers ─────────────────────────────────────────────────────

function telegramPost(path: string, payload: object): Promise<string> {
  const body = JSON.stringify(payload);
  const options = {
    hostname: "api.telegram.org",
    path,
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Content-Length": Buffer.byteLength(body),
    },
  };
  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (c: Buffer) => (data += c));
      res.on("end", () => resolve(data));
    });
    req.on("error", (err: Error) => {
      log("Telegram API error: " + err, "bot");
      resolve("");
    });
    req.write(body);
    req.end();
  });
}

// parse_mode is now HTML — URLs with underscores are never mangled
async function sendMessage(chatId: number | string, text: string, token: string): Promise<void> {
  await telegramPost("/bot" + token + "/sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
  });
}

async function setWebhook(token: string, webhookUrl: string): Promise<void> {
  const result = await telegramPost("/bot" + token + "/setWebhook", { url: webhookUrl });
  log("Webhook set: " + result, "bot");
}

// ─── Express routes ───────────────────────────────────────────────────────────

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  const token = process.env.TELEGRAM_TOKEN;

  if (!token) {
    log("TELEGRAM_TOKEN not set — bot disabled", "bot");
    return httpServer;
  }

  await loadPhoneList();

  app.post("/bot" + token, async (req, res) => {
    res.sendStatus(200);
    try {
      const update = req.body;
      const message = update.message || update.channel_post;
      if (!message || !message.text) return;
      await loadPhoneList();
      const reply = handleMessage(message.text);

      if (reply === "__LIST__") {
        // Wrap the entire numbered list in a <pre> block:
        //   - always renders LTR (fixes RTL alignment inconsistencies)
        //   - compact enough to fit all numbers in one message
        //   - tapping the block in Telegram copies the whole list
        const header = "<b>\uD83D\uDCCB \u05DE\u05D0\u05D2\u05E8 \u05DE\u05E1\u05E4\u05E8\u05D9 \u05D4\u05E2\u05D5\u05E7\u05E5 (" + phoneList.length + " \u05DE\u05E1\u05E4\u05E8\u05D9\u05DD):</b>\n\n";
        const maxIndex = String(phoneList.length).length;
        const lines = phoneList.map((num: string, i: number) => {
          const idx = String(i + 1).padStart(maxIndex, " ");
          return idx + ". " + num;
        });
        const body = "<pre>" + lines.join("\n") + "</pre>";
        await sendMessage(message.chat.id, header + body, token);
      } else {
        await sendMessage(message.chat.id, reply, token);
      }
    } catch (err) {
      log("Error processing update: " + err, "bot");
    }
  });

  const domain = process.env.REPLIT_DOMAINS?.split(",")[0];
  if (domain) {
    const webhookUrl = "https://" + domain + "/bot" + token;
    await setWebhook(token, webhookUrl);
    log("Webhook registered at https://" + domain + "/bot<token>", "bot");
  } else {
    log("REPLIT_DOMAINS not available — webhook URL unknown", "bot");
  }

  return httpServer;
}
